/* 
    Banner ID - 100918938
    Name - Francis Chang Price
    Description -  Animating splash page and landing page
*/

window.onload = function () {
    // reference the Splash SVG file
    const theObject = document.getElementById('splash').contentDocument; //getting the elements from the document 
    const theBkground = theObject.getElementById('bkground');
    const theLogoFork = theObject.getElementById('logofork');
    const theLogoKnife = theObject.getElementById('logoknife');
    const theLogoTitle = theObject.querySelectorAll('.foeStyle');
    // reference the SVG file
    const theLanding = document.getElementById('landing').contentDocument;
    let theSVG = document.getElementById('landingPage').getBoundingClientRect();
    const theBkgroundLanding = theLanding.getElementById('bkground');
    const landingTop = theLanding.getElementById('topBanner');
    const landingBot = theLanding.getElementById('botBanner');
    const foeLogo = theLanding.getElementById('logo');
    const theWording = theLanding.getElementById('wording');
    const theTitle = theLanding.querySelectorAll('.fontStyle') //must provide the proper syntax for class and id
    const theRestLogos = theLanding.querySelectorAll('.btnStyle');  // create a class for the number of logos (in the SVG) to target them together with selector all 

    // referencing the Restaurant SVG file
    const theRestaurant = document.getElementById('restaurant').contentDocument;
    const restTop = theRestaurant.getElementById('topBanner');
    const restMenu = theRestaurant.getElementById('menu');
    const restName = theRestaurant.getElementById('name');
    const restHome = theRestaurant.getElementById('homeContent');
    const restSpecial = theRestaurant.getElementById('specialContent');
    const restBot = theRestaurant.getElementById('botBanner');
    const theButtons = theRestaurant.querySelectorAll('.buttonStyle');
    const theHovers = theRestaurant.querySelectorAll('.hoverStyle');
    const theHome = theRestaurant.querySelectorAll('.homeStyle');
    const theSpecial = theRestaurant.querySelectorAll('.specialStyle');
    // allows us to keep the restuarant hovers off and the restaurant icon off
    gsap.set([restSpecial], {
        opacity: 0,
    });

    // referencing the Reservation Form 
    const theReservation = document.querySelector('.reservation');
    const theReserve = document.querySelectorAll('.reveal');
    gsap.set(theReservation, { autoAlpha: 0 });


    // background
    gsap.from(theBkground, {
        opacity: 0,
        duration: 1.5,
        delay: 1
    });

    // the fork from the logo showing from the right
    gsap.from(theLogoFork, {
        delay: 2.1,
        x: -350,
        ease: 'back.out'
    });

    // the knife from the logo showing from the left
    gsap.from(theLogoKnife, {
        delay: 2.1,
        x: 350,
        ease: 'back.out'
    })

    // logo writing appears
    gsap.from(theLogoTitle, {
        transformOrigin: 'center center',
        delay: 2.3,
        scale: 0,
        stagger: 0.2,
        duration: 0.5,
        ease: "back.out"
    });

    // clear the splash page section and reveal the landing page
    gsap.to('#splashPage', {
        delay: 7,
        ease: 'power4.out',
        display: 'none',
        onComplete: prepareLanding // creating a function that will display the animations of the Landing page
    });

    // function prepareLanding
    function prepareLanding() {
        // background shows
        gsap.from(theBkgroundLanding, {
            opacity: 0,
            duration: 1,
            delay: 0.2,
        });

        // topbanner, logo and wording dropping down
        gsap.from(landingTop, {
            delay: .6,
            y: -200,
            duration: .5,
            ease: "sine.out"
        });

        //botbanner coming upi 
        gsap.from(landingBot, {
            delay: .8,
            opacity: 0,
            y: 300,
            duration: .5,
            ease: "sine.out"
        });

        // the logo showing from scaling position
        gsap.from(foeLogo, {
            transformOrigin: 'center center',
            delay: 1.1,
            scale: 0,
            duration: .7,
        });

        // wording box coming down 
        gsap.from(theWording, {
            delay: 1.8,
            y: -300,
            duration: .7,
            ease: "sine.out"
        });

        // // title showing 
        gsap.from(theTitle, {
            delay: 2.6,
            opacity: 0,
            duration: 0.3,
        });

        // restaurant logos showing
        gsap.from(theRestLogos, {
            transformOrigin: 'center bottom', //this will make the scaling to happen from the top down. y x position
            delay: 3.7,
            stagger: .3,
            scale: 0,
            ease: "sine.out"
        });
        //zoom in logos one at a time 

        //initiate click event for each logo - the restaurant page and all animations have to be inside here
        theRestLogos.forEach((btn, index) => {
            // click event for the logos
            btn.addEventListener('click', () => {
                // landing page will be displayed none
                // gsap.set('#landingPage', {
                //     display: 'none',
                // });
                // setting default when the button is clicked 
                theSVG = document.getElementById('landingPage').getBoundingClientRect();
                // the landing will move when restaurant is clicked
                gsap.set('#landingPage', {
                    x: -theSVG.width
                });
                // the restaurant page will move to the top when the restaurant is clicked
                gsap.set('#restaurantPage', {
                    y: -theSVG.height
                });
                // default states for the hovers
                gsap.set([theHovers, restSpecial, restHome], {
                    opacity: 0
                });
                gsap.set(theReservation, {
                    autoAlpha: 0
                });
                gsap.set([restHome, theHovers[0]], {
                    opacity: 1
                })
                // animation for the restaurant Home page using the elements together
                // gsap.from(theHome, {
                //     y: -20, opacity: 0, stagger: .2
                // });

                // animation for the home page
                gsap.fromTo(theHome, {
                    y: -20,
                    opacity: 0
                }, {
                    y: 0,
                    opacity: 1,
                    stagger: .2
                })

                // click event for the home, special and reservation buttons
                theButtons.forEach((icon, i) => {
                    // the icon is the name given to the elements in illustrator 
                    icon.addEventListener('click', () => {
                        // three outcomes for the buttons
                        switch (i) {
                            case 0:
                                gsap.set(restHome, { opacity: 1 });
                                gsap.set([theHovers, restSpecial], {
                                    opacity: 0
                                });
                                gsap.set(theReservation, {
                                    autoAlpha: 0
                                })
                                // gsap.from(theHome, {
                                //     y: -200,
                                //     opacity: 0,
                                //     stagger: 0.2,
                                // });
                                gsap.fromTo(theHome, {
                                    y: -20,
                                    opacity: 0
                                }, {
                                    y: 0,
                                    opacity: 1,
                                    stagger: .2,
                                });
                                break;

                            case 1:
                                gsap.set(restSpecial, {
                                    opacity: 1,
                                });
                                gsap.set([theHovers, restHome], {
                                    opacity: 0
                                });
                                gsap.set(theReservation, {
                                    autoAlpha: 0
                                })
                                // gsap.from(theSpecial, {
                                //     y: -200,
                                //     opacity: 0,
                                //     stagger: 0.2,
                                // });

                                gsap.fromTo(theSpecial, {
                                    y: -20,
                                    opacity: 0
                                }, {
                                    y: 0,
                                    opacity: 1,
                                    stagger: .2,
                                })

                                break;

                            case 2:
                                gsap.set(theReservation, {
                                    autoAlpha: 1
                                });
                                gsap.set([theHovers, restHome, restSpecial], {
                                    opacity: 0,
                                });
                                gsap.fromTo(theReserve, {
                                    y: -20,
                                    opacity: 0
                                }, {
                                    y: 0,
                                    opacity: 1,
                                    stagger: .2,
                                });
                                break;

                            default:
                                gsap.set(theReservation, {
                                    autoAlpha: 0,
                                });

                                gsap.set(restHome, {
                                    opacity: 1,
                                });
                                gsap.set([theHovers, restSpecial], {
                                    opacity: 0
                                });
                                gsap.fromTo(theHome, {
                                    y: -20,
                                    opacity: 0
                                }, {
                                    y: 0,
                                    opacity: 1,
                                    stagger: .2,
                                });
                                break;
                        };

                    });
                });
            });
        });
    }
} // end window onload 
